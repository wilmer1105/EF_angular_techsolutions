import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReporteService {

  private apiUrl = 'http://localhost:8080/api/reportes';

  constructor(private http: HttpClient) { }

  // Método para descargar el PDF General
  descargarPdfGeneral(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/incidencias/pdf`, { responseType: 'blob' });
  }

  // Método para descargar el PDF filtrado por Estado
  descargarPdfPorEstado(idEstado: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/incidencias/estado/${idEstado}/pdf`, { responseType: 'blob' });
  }
}