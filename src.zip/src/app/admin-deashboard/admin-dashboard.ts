import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { IncidenciaService } from '../services/incidencia';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ReporteService } from '../services/reporte.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  incidencias: any[] = [];
  tecnicos: any[] = [];
  nombreAdmin: string = 'Administrador';
  mensajeExito: string = '';

  incidenciaSeleccionada: any = null;
  idTecnicoSeleccionado: number | null = null;
  observacionAsignacion: string = '';

  // Lista estática o dinámica de gravedades según tu BD (ejemplo común: 1=Baja, 2=Media, 3=Alta, 4=Crítica)
  listaPrioridades = [
    { id: 1, nombre: 'Baja' },
    { id: 2, nombre: 'Media' },
    { id: 3, nombre: 'Alta' },
    { id: 4, nombre: 'Crítica' }
  ];

  constructor(
    private incidenciaService: IncidenciaService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private reporteService: ReporteService
  ) {}

  ngOnInit(){
    const adminGuardado = localStorage.getItem('nombre_usuario_logueado');
    if (adminGuardado) {
      this.nombreAdmin = adminGuardado;
    }
    this.cargarDatos();
  }

  cargarDatos() {
    this.incidenciaService.getAllIncidencias().subscribe({
      next: (data) => {
        this.incidencias = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error al cargar incidencias:', err)
    });

    this.incidenciaService.getTecnicos().subscribe({
      next: (data) => {
        this.tecnicos = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error al cargar técnicos:', err)
    });
  }

  cambiarGravedad(idIncidencia: number, event: any) {
    const idPrioridad = Number(event.target.value);
    this.incidenciaService.actualizarPrioridadIncidencia(idIncidencia, idPrioridad).subscribe({
      next: (res) => {
        this.mensajeExito = '¡Gravedad de la incidencia actualizada correctamente!';
        this.cargarDatos();
        setTimeout(() => { this.mensajeExito = ''; this.cdr.detectChanges(); }, 3000);
      },
      error: (err) => console.error('Error al cambiar la prioridad', err)
    });
  }

  seleccionarIncidencia(incidencia: any) {
    this.incidenciaSeleccionada = incidencia;
    this.idTecnicoSeleccionado = null;
    this.observacionAsignacion = '';
    this.cdr.detectChanges();
  }

  guardarAsignacion() {
    if (!this.idTecnicoSeleccionado) {
      alert('Por favor, seleccione un técnico.');
      return;
    }
    const payload = {
      id_incidencia: this.incidenciaSeleccionada.id_incidencia,
      id_tecnico: Number(this.idTecnicoSeleccionado),
      observacion: this.observacionAsignacion
    };

    this.incidenciaService.asignarTecnico(payload).subscribe({
      next: (res) => {
        this.mensajeExito = `¡Incidencia #${payload.id_incidencia} asignada con éxito!`;
        this.incidenciaSeleccionada = null;
        this.cargarDatos();
        setTimeout(() => { this.mensajeExito = ''; this.cdr.detectChanges(); }, 4000);
      },
      error: (err) => console.error('Error al asignar técnico', err)
    });
  }

  cerrarSesion() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  descargarReporteGeneral(): void {
    this.reporteService.descargarPdfGeneral().subscribe({
      next: (blob: Blob) => {
        // Crear un objeto URL para archivo binario recibido
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        // El navegador usará el nombre enviado por las cabeceras de Spring Boot,
        // pero le ponemos uno por defecto como salvaguarda
        a.download = `Reporte_General_${new Date().getTime()}.pdf`; 
        
        // Disparar la descarga automática
        document.body.appendChild(a);
        a.click();
        
        // Limpieza de memoria
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      },
      error: (err) => {
        console.error('Error al descargar el PDF:', err);
        alert('No se pudo generar el reporte en este momento.');
      }
    });
  }
}